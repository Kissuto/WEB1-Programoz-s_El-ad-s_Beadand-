<?php
// config.php
$host = 'localhost';
$db   = 'beadando';
$user = 'felhasznalo';
$pass = 'jelszo';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Hiba: " . $e->getMessage());
}
?>