<?php
// get_posztok.php
header('Content-Type: application/json');
require_once 'beadando.php';

$stmt = $pdo->query("SELECT id, nev FROM poszt");
$adatok = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($adatok);
?>